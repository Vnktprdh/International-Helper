package com.internationalhelper.internationalhelper.Adapters;

import android.widget.Filter;

public interface getFilterItem {
    Filter getFilter();
}
